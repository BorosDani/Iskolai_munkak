﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LottoSzamok
{
    class Program
    {
        static void Main(string[] args)
        {
            //ötöslottó feladat
            List<int> otvenkettedikHet = new List<int>(); 


            //1. feladat
            Console.WriteLine("1. 52.hét számai");
            Console.WriteLine("Kérem adja meg az 52.heti lottószámokat!"); //bekérjük az 52.heti lottószámok
            bool helyes = false;
            int szam = 0;
                for (int i = 0; i < 5; i++)
                {
                helyes = false;
                    Console.Write((i+1)+". szám: ");
                    szam = Convert.ToInt32(Console.ReadLine());
                    while (helyes != true)
                    {
                        if (szam > 90 || szam < 0)
                        {
                            Console.WriteLine();
                            Console.Write("Kérek egy új számot(1-90): ");
                            szam = Convert.ToInt32(Console.ReadLine());
                        }
                        else
                        {
                            helyes = true;
                        }
                    }
                    otvenkettedikHet.Add(szam);
                    Console.WriteLine();
                }
            Console.WriteLine();


            //2.feladat - Sorba rendezés és kiíratása
            Console.WriteLine("2.sorba rendezés");
            otvenkettedikHet.Sort();
            for (int i = 0; i < otvenkettedikHet.Count(); i++)
            {
                Console.Write(otvenkettedikHet[i] + " ");
            }
            Console.WriteLine(); 
            Console.WriteLine();


            //3.feladat - fájlba olvasás
            Console.WriteLine("3.feladat");
            StreamReader olvasocsatorna = new StreamReader(@"Z:\prigi\lottoszamok.csv", Encoding.GetEncoding("iso-8859-2"), false);
            string sorok = olvasocsatorna.ReadLine();
            List<string> LottoSzamok = new List<string>();

            while (sorok != null)
            {
                LottoSzamok.Add(sorok);
                sorok = olvasocsatorna.ReadLine();
            }
            
            olvasocsatorna.Close();
            Console.WriteLine();

           
            //4.feladat
            Console.WriteLine("4.feladat:");
            Console.Write("Kérek egy számot (1-90-ig): ");
            int sor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine();


            //5.feladat
            Console.WriteLine("5.Számmal megfelelő sor kiíratása");

            if (sor - 1 >= 0 && sor - 1 < LottoSzamok.Count)
            {
                Console.WriteLine("A kért hét lottószámai: " + LottoSzamok[sor - 1]);
            }
            else
            {
                Console.WriteLine("Nincs ilyen hét... :(");
            }

            Console.ReadKey();

        }
    }
}
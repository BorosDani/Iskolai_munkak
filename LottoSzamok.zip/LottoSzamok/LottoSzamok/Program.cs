﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LottoSzamok
{
    class Program
    {
        static void Main(string[] args)
        {
            //ötöslottó
            //3. feladat - Fájl beolvasás

            StreamReader olvasocsatorna = new StreamReader(@"Z:\prigi\lottoszamok.csv", Encoding.GetEncoding("iso-8859-2"), false);

            //1. feladat
            Console.WriteLine("Kérem adja meg az 52.heti lottószámokat"); //bekérjük az 52.heti lottószámok
            List<int> LottoSzamok = new List<int>();
            int tippek = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.Write((i+1)+". szám: ");
                tippek = Convert.ToInt32(Console.ReadLine());

                //2.feladat - Sorba rendezés és kiíratása
                
            }


            string sor = olvasocsatorna.ReadLine();
            int sorokSzama = 0;

            while (sor != null)
            {
                sorokSzama++;
                sor = olvasocsatorna.ReadLine();
            }

            olvasocsatorna.Close();
            //4. feladat - Bekérünk egy számot 1-51 között.
            Console.Write("Kérlek adj meg egy számot 1-51 között: ");
            int szam = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            //5.feladat- szam megfelelő heti lottószámai
            for (int i = 0; i < sorokSzama; i++)
            {
                if (LottoSzamok[szam] == i)
                {
                    Console.WriteLine(LottoSzamok[szam]);
                }
            }

            //6. feladat - Döntse el, hogy volt-e olyan szám, amit egyszer sem húztak ki az 51 hét alatt!
            int[] tomb = new int[]{ };

            for (int i = 0; i < sorokSzama; i++)
            {
                foreach (int szamok in LottoSzamok)
                {
                    tomb[i] = LottoSzamok[i];

                }
            }

            //7.feladat - Hány páratla szám volt?
            int[] paratlanok = new int[]{ };
            for (int i = 0; i < LottoSzamok.Count; i++)
            {
                if (LottoSzamok[i] % 3 == 0)
                {
                    paratlanok[i] = LottoSzamok[i];
                }
            }
            foreach (int paratlan in paratlanok)
            {
                Console.Write(paratlan + " ");
            }

            //8.feladat - 

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}

<?php
    header('Content-Type: application/json; charset=utf-8');

    $error = 0;

    if(!isset($_GET['ado']))
    {
        $tomb = array
        (
            'Hiba        ' => "Hiányos adatok" ,  
            'Üzenet      ' => "Megadandó paraméterek: ?ado=",
            'Error       ' => $error = $error + 1
        );
    }

    else
    {
        $KezdetiDatum = '1867-01-01';
        $azonosito = $_GET['ado'];
        $NapokSzama = intval($azonosito[1] . $azonosito[2] . $azonosito[3] . $azonosito[4] . $azonosito[5]);

        if($azonosito[0] != 8)
        {
            $tomb = array
            (
                'Hiba        ' => "Hiányos vagy rossz adat",
                'Üzenet      ' => "Nem 8-al kezdődik az azonosítód!",
                'Error       ' => $error = $error + 1
            );
        }

        elseif(strlen($azonosito) != 10)
        {
            $tomb = array
            (
                'Hiba        ' => "Hiányos adatok",
                'Üzenet      ' => "Nincs meg a 10 szám az azonosítóhoz!",
                'Error       ' => $error = $error + 1
            );
        }
        else
        {
            $tomb = array
            (
                'Adóazonosító      ' => $azonosito,
                'Születési dátum   ' => date('Y-m-d', strtotime($KezdetiDatum. " + {$NapokSzama} days")),
                'Error             ' => $error++
            );
        }
    }

    $json = json_encode($tomb, JSON_UNESCAPED_UNICODE);
    print $json;
?>
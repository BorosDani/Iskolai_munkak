﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kockadobasok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            kockadobasok();
            Console.ReadLine();

            GeneraltKockadobasok();
            Console.ReadLine();
        }

        private static void kockadobasok() 
        {
            //Feladatok kiírása.
            Console.WriteLine("--- Kockadobásos feladatok ---\n");
            Console.WriteLine("a) Hány dobást tárolunk a fájlban?");
            Console.WriteLine("b) Mennyi hatos volt?");
            Console.WriteLine("c) A dobások hány százaléka volt egyes? (2 tizedesjegyre)");
            Console.WriteLine("d) Hányszor fordult elő, hogy két hatos volt egymás után?");
            Console.WriteLine("e) Hányszor fordult elő 6-5-4 sorozat?\n\n\n");

            //Beolvasás és feladat elvégzés.
            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas_dolgozatok\kockadobasok.csv", false);
            List<int> dobasok = new List<int>();
            string sor = olvasocsatorna.ReadLine();
            int hatosok_szama = 0;
            double egyesek_szama = 0;
            int KetHatos = 0;
            int hat_ot_negy = 0;

            //Beolvasom, tárolom a dobások listában.
            while (sor != null) 
            {
                sor = olvasocsatorna.ReadLine();
                dobasok.Add(Convert.ToInt32(sor));
            }

            //Kiszámolom hány hatos illetve egyes van.
            for (int i = 0; i < dobasok.Count; i++)
            {
                //Hatosok száma.
                if (dobasok[i] == 6)
                {
                    hatosok_szama++;
                }
                //Egyesek száma.
                else if (dobasok[i] == 1) 
                {
                    egyesek_szama++;
                }
            }

            //Kiszámolom hányszor fordul elő két hatos egymás után.
            for (int i = 1; i < dobasok.Count; i++) 
            {
                if (dobasok[i] == 6 && dobasok[i - 1] == 6) 
                {
                    KetHatos++;
                }
            }

            //Kiszámolom hányszor fordul elő 6-5-4 sorozat.
            for (int i = 1; i < dobasok.Count; i++)
            {
                if (dobasok[i] == 4 && dobasok[i - 1] == 5 && dobasok[i-2] == 6)
                {
                    hat_ot_negy++;
                }
            }

            olvasocsatorna.Close();

            //Fájlba írás
            StreamWriter irocsatorna = new StreamWriter(@"Z:\programozas_dolgozatok\kockadobasok_eredmenye.csv", false, Encoding.GetEncoding("iso-8859-2"));

            //Eredmények kiírása
            irocsatorna.WriteLine("--- Kockadobás megoldások ---\n");
            irocsatorna.WriteLine("a) Tárolt elem: {0}", dobasok.Count);
            irocsatorna.WriteLine("b) Hatosok száma: {0}", hatosok_szama);
            irocsatorna.WriteLine("c) Egyesek százaléka: {0}%", Math.Round((egyesek_szama/dobasok.Count)*100,2));
            irocsatorna.WriteLine("d) Két hatos egymás után: {0}", KetHatos);
            irocsatorna.WriteLine("e) 6-5-4 sorozat: {0}", hat_ot_negy);

            irocsatorna.Close();
            Console.WriteLine("Eredmények kiírva egy fájlba...");
        }

        private static void GeneraltKockadobasok() 
        {
            //Feladat ismertetése.
            Console.WriteLine("--- Számok generálása bekéréssel ---\n");

            //Dobások számának bekérése
            Console.Write("Hány dobás legyen? ");
            int dobasok_szama = Convert.ToInt32(Console.ReadLine());

            //Random szám
            Random rnd = new Random();

            //Fájl készítése
            StreamWriter irocsatorna = new StreamWriter("kockadobasok_generalt.csv");

            //Random szám beírása a fájlba
            for (int i = 0; i < dobasok_szama; i++) 
            {
                irocsatorna.WriteLine(rnd.Next(1,7)); //1-6 ig random szám generálása
            }

            irocsatorna.Close();
            Console.WriteLine("\nFájlba írás befejeződött...");
        }
    }
}

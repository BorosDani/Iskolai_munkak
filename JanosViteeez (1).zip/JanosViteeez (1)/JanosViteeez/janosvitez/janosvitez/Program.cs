﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace JanosVitez
{
    class Program
    {

        static void Main(string[] args)
        {
            feladatok();
            Console.ReadKey();
        }

        static void feladatok()
        {
            StreamReader olvasocsatorna = new StreamReader(@"Z:\JanosViteeez (1)\JanosViteeez\JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);
            string[] szavak = olvasocsatorna.ReadLine().Split(' ');
            olvasocsatorna.Close();


            //1.feladat
            Console.WriteLine("1. feladat- Hány szóbol áll a vers részlet? ");

            Console.WriteLine($"1.feladat: A vers részlet ennyi szót tartalmaz: {szavak.Length}");
            Console.WriteLine();

            //2.feladat: Mennyi betű a leghosszabb szó?
            Console.WriteLine("2.feladat - Hány betüből áll a leghosszabb szó?");

            string leghosszabb_szo = "";

            for (int i = 0; i < szavak.Length; i++)
            {
                if (szavak[i].Length > leghosszabb_szo.Length)
                {
                    leghosszabb_szo = szavak[i];               
                }
            }


            Console.WriteLine("2.feladat: A legtöbb betüből álló szó: "+ leghosszabb_szo.Length);
            Console.WriteLine();

            //3.feladat: Hányszor szerepel az "a" nevelő
            Console.WriteLine("3.feladat - Hányszor szerepel az (a) nevelő?");
            int szam_a = 0;

            for (int i = 0; i < szavak.Length; i++)
            {
                if (szavak[i] == "a" || szavak[i] == "A")
                {
                    szam_a++;
                }

            }
            Console.WriteLine($"3.feladat: A versben {szam_a}-szor/ször szerepel.");
            Console.WriteLine();

            //4.feladat: Hány nevelő van benne?
            Console.WriteLine("4.feladat - Hány nevelő szerepel?");
            int nevelokSzama = 0;

            for (int i = 0; i < szavak.Length; i++)
            {
                if (szavak[i] == "a" || szavak[i] == "az" || szavak[i] == "A" || szavak[i] == "Az")
                {
                    nevelokSzama++;
                }
            }
            Console.WriteLine("4.feladat: Ennyi nevelő szerepel a versben: " + nevelokSzama);
            Console.WriteLine();

            //5.Melyik a 10. szó
            Console.WriteLine("5.feladat - Melyik a tizedik szó?");
            string tizedikszo = szavak[9];

            Console.WriteLine("5.feladat: A tizedik szó a versben: " + tizedikszo);
            Console.WriteLine();


            //6. Hány szó tartalmaz nagybetűt?
            Console.WriteLine("6.feladat: Hány szó tartalmaz nagy betűt:");
            int osszesNagyBetusSzo = 0;
            foreach ( string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    if (karakter >= 'A' && karakter <= 'Z')
                    {
                        osszesNagyBetusSzo++;
                    }
                }
            }

            Console.WriteLine("6.feladat: Ennyi szó tartalmaz nagy betűt: "+ osszesNagyBetusSzo);


            Console.WriteLine();
            Console.WriteLine("7.feladat: Összes előforduló írásjel összege: ");
            int osszIrasjel = 0;
            foreach (string szo in szavak)
            {
                foreach(char karakter in szo)
                {
                    if (karakter == '.' || karakter == ',' || karakter == '?' || karakter == '!')
                    {
                        osszIrasjel++;            
                    }
                }
            }
            Console.WriteLine("7.feladat: Az összes írásjel összege: "+ osszIrasjel);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace janosvitez_2
{
    class Program
    {
        static void Main(string[] args)
        {
            feladatok();
        }
        static void feladatok()
        {
            StreamReader olvasocsatorna = new StreamReader(@"Z:\JanosViteeez (1)\JanosViteeez\JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);
            string[] szavak = olvasocsatorna.ReadLine().Split(' ');
            olvasocsatorna.Close();

            Console.Write("Kérlek adj meg egy betűt: ");
            char betu = Convert.ToChar(Console.ReadLine());
            int osszeg = 0;
            //a betű előfordulásának számolása
            foreach (string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    if (karakter == betu)
                    {
                        osszeg++;
                    }
                }
                
            }
            Console.WriteLine("A betük előfordulása: " + osszeg);
            Console.WriteLine();


            //b - Első szó
            string elso_szo= " ";

            foreach (string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    if (karakter == betu)
                    {
                        elso_szo = szo;
                    }
                }
            }
            Console.WriteLine($"Az első szó amiben szerepel a(z) {betu} betű: {elso_szo}");
            Console.WriteLine();

            //c - fordított sorrendben kiírása
            for (int i = szavak.Length - 1; i > 0; i--)
            {
                Console.Write(szavak[i] +" "); 
            }
            Console.WriteLine();
            Console.WriteLine(  );

            //d -ritkitás 
            foreach (string szo in szavak)
            {
                foreach (char karakterek in szo)
                {
                    Console.Write(karakterek + " ");
                }
                Console.Write(" ");
            }
            Console.WriteLine();


            //e - írás függöleges oszlopba(szó / betű)
            StreamWriter irocsatorna = new StreamWriter(@"Z:\JanosViteeez (1)\JanosViteeez\JanosVitezFuggoleges.txt", false, Encoding.GetEncoding("iso-8859-2"));
            irocsatorna.WriteLine("Szavanként:");

            foreach (string szo in szavak)
            {
                irocsatorna.WriteLine(szo);
            }

            irocsatorna.WriteLine("Betűnként:");

            foreach (string szo in szavak)
            {
                foreach (char karakterek in szo)
                {
                    irocsatorna.WriteLine(karakterek);
                }
            }

            irocsatorna.Close();
            Console.WriteLine();


            //f - Szerepel-e a szó?
            

            Console.Write("Kérek egy szót ami szerepelhet a versben: ");
            string szoveg = Console.ReadLine();
            Console.WriteLine();

            bool szerepel = false;
            int hanyadik = 0;
            for (int i = 0; i < szavak.Length; i++)
            {
                if (szavak[i].ToLower() == szoveg)
                {
                    szerepel = true;
                    hanyadik = (i + 1);
                }
            }

            if (szerepel)
            {
                Console.WriteLine($"Ez a szó megtalálható a versebeb. {hanyadik}. szó volt.");

            }
            else
            {
                Console.WriteLine("Ez a szó nem szerepel a versben");
            }
            

            //g - addig bekérés amíg helyes nem lesz
            bool siker = false;

            while (siker != true)
            {
                Console.Write("Kérek egy szót ami szerepelhet a versben: ");
                string szov = Console.ReadLine();
                Console.WriteLine();

                for (int i = 0; i < szavak.Length; i++)
                {
                    if (szavak[i].ToLower() == szov)
                    {
                        siker = true;
                        Console.WriteLine("Eltaláltál egy szót a versből, ügyes vagy! ");
                    }
                }
            }
            Console.WriteLine();
            //h - Hány betű van összesen
            int osszes = 0;
            for (int i = 0; i < szavak.Length; i++)
            {
                osszes = osszes + szavak[i].Length;
            }
            int osszIrasjel = 0;
            foreach (string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    if (karakter == '.' || karakter == ',' || karakter == '?' || karakter == '!')
                    {
                        osszIrasjel++;
                    }
                }
            }
            osszes = osszes - osszIrasjel;
            Console.WriteLine("Az összes betű összege: " + osszes);

            


            Console.ReadKey();

        }
    }
}


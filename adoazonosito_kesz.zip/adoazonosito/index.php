<?php
    header('Content-Type: application/json; charset=utf-8');

    if(!isset($_GET['ado']))
    {
        $tomb = array('hiba' => "hiányos adatok", 'uzenet' => "Adóazonosító megadása: ?ado=");
    }

    else
    {
        for($i = 1; $i <= 5; $i++)
        {
            $hszam = array_walk($_GET['ado'[$i]]);
        }
        $tomb = array(
            'Adóazonosító' => $_GET['ado'],
            'Hatszam' => $hszam2,
                    );
    }

    $json = json_encode($tomb, JSON_UNESCAPED_UNICODE);
    print $json;
?>
<?php
	header('Content-Type: application/json; charset=utf-8');

	if(!isset($_GET['ev']))
	{
		$tomb = array('hiba' => "hiányos adatok" ,  'uzenet' => "megadandó paraméterek: ev");
	}

	else
	{
		$ev = $_GET['ev'];
		$A = $ev / 19;
		$B = $ev / 4;
		$C = $ev / 7;
		$D = (19 * $A + 24) / 30;
		$E = (2 * $B + 4 * $C + 6*$D + 5) / 7;
		$H = 22 + $D + $E;

	}

	$tomb = array(
			'Év' => $_GET['ev'],
			'Húsvet' => $A,
			'h' => $B,
			'j' => $C,
			'l' => $D,
			'á' => $E,
			'z' => $H
	);

	$json = json_encode( $tomb , JSON_UNESCAPED_UNICODE ) ;

    print $json ;
?>
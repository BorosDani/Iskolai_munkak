<?php
    header('Content-Type: application/json; charset=utf-8');

    $kezdodatum = '2021-06-24';
    $kezdoidopont = '20:40';

    $adat = "";

    if($_GET['datum'] == "")
    {
        $msperc = mktime(20, 40, 0, 6, 24, 2021); //óra, perc, másodp., hónap, nap, év 
    }

    $adat = $_GET['datum'] . ":" .$_GET['db'];
    $FeldaraboltAdat = explode(':', $adat);

    $tomb = array
    (
        ''
    );
?>
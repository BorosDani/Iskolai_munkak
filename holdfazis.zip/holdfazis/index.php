<?php
    header('Content-Type: application/json; charset=utf-8');

    $kezdodatum = '2021-06-24';
    $kezdoidopont = '20:40';
    $MegadottDatum = $_GET['datum'];
    if($_GET['datum'] == "")
    {
        $msperc = mktime(20, 40, 0, 6, 24, 2021); //óra, perc, másodp., hónap, nap, év 
    }

    else
    {
        $msperc = mktime($MegadottDatum[0], $MegadottDatum[1], $MegadottDatum[2]);
    }

    $tomb = array
    (
        'Dátum Másodpercben' => $msperc,
        'Dátum' => date("Y-m-d ; H:m:s", strtotime($MegadottDatum))
    );

    $json = json_encode($tomb, JSON_UNESCAPED_UNICODE);
    print $json;
?>
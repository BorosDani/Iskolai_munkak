﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szorzotabla
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
            Console.ReadKey();
        }

        private static void menu() 
        {
            while (true) 
            {
                Console.WriteLine("    Üdvözöllek!");
                Console.WriteLine("------------------");
                Console.WriteLine("| 1. Szorzótábla |");
                Console.WriteLine("| 2. Tudnivalók  |");
                Console.WriteLine("| 3. Kilépés     |");
                Console.WriteLine("-------------------");

                int valasztas = Convert.ToInt32(Console.ReadLine());
                if (valasztas == 1)
                {
                    //szorzotabla();
                }

                 else if (valasztas == 2)
                {
                    Console.Clear();
                    tudnivalok();
                    Console.ReadKey();
                    Console.Clear();

                }

                else if (valasztas == 3)
                {
                    kilepes();
                }

                else Console.WriteLine("Nincs ilyen szám!");
            }
        }


        private static void tudnivalok() 
        {
            Console.WriteLine("\t-----Szia! az én nevem G.E.R.I-----\n");
            Console.WriteLine("- Hosszabbik nevem: Gyakorlati Eredmények Rendszeres Ismétlése");
            Console.WriteLine("- Elmondom neked a tudnivalókat a szorzótáblával kapcsoltaban, hogy mit is kell csinálnod :)");
            Console.WriteLine("\n----- NYOMJ EGY ENTERT, ÍGY VISSZATÉRSZ A MENÜBE :) -----");
        }

        private static void kilepes() 
        {
            Environment.Exit(0);
        }
    }
}

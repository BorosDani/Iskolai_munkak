﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szorzotabla
{
    class Program
    {
        static void Main(string[] args)
        {
            menu();
            Console.ReadKey();
        }

        private static void menu() 
        {
            while (true) 
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("  - Üdvözöllek, G.E.R.I vagyok :)");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\t------------------");
                Console.WriteLine("\t| 1. Játék       |");
                Console.WriteLine("\t| 2. Szorzótábla |");
                Console.WriteLine("\t| 3. Tudnivalók  |");
                Console.WriteLine("\t| 4. Kilépés     |");
                Console.WriteLine("\t-------------------");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n- írj be egy 3-ast, hogy információkat tudj meg");
                Console.ForegroundColor = ConsoleColor.White;

                Console.Write("\n#");
                Console.ForegroundColor = ConsoleColor.Cyan;
                string valasztas = Console.ReadLine();

                while (valasztas != "1" && valasztas != "2" && valasztas != "3" && valasztas != "4")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Nincs ilyen szám!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("#");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    valasztas = Console.ReadLine();
                    
                }


                if (valasztas == "1")
                {
                    Console.Clear();
                    jatek();
                    Console.Clear();
                }

                else if (valasztas == "2")
                {
                    Console.Clear();
                    szorzotabla();
                    Console.Clear();
                }

                else if (valasztas == "3")
                {
                    Console.Clear();
                    tudnivalok();
                    Console.ReadKey();
                    Console.Clear();
                }

                else if (valasztas == "4")
                {
                    Console.Clear();
                    kilepes();
                    Console.Clear();
                }
            }
        }

        private static void jatek() 
        {
            Random rnd = new Random();
            int[] randomszamok = new int[5];
            int jelenlegi_rnd_szam = 0;
            bool ismetlodes = false;

            for(int i = 0; i < randomszamok.Length; i++) 
            {
                do
                {
                    ismetlodes = false;
                    jelenlegi_rnd_szam = rnd.Next(1, 11);

                    for (int j = 0; j < i; j++)
                    {
                        if (randomszamok[j] == jelenlegi_rnd_szam)
                        {
                            ismetlodes = true;
                        }
                    }
                } while (ismetlodes);
                randomszamok[i] = jelenlegi_rnd_szam;
            }


            int tippek;
            int pont = 0;
            int eredmeny;

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("--- Játék ---");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Írj be egy számot: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            int szam = Convert.ToInt32(Console.ReadLine());

            while(szam > 10 || szam < 1) 
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("- 1 és 10 között adj meg számokat!(Gondolom nem olvastad a tudnivalókat ejnye :/ )");
                Console.ForegroundColor = ConsoleColor.Cyan;
                szam = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < 5; i++)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("{0} * {1} = ", randomszamok[i], szam);
                eredmeny = randomszamok[i] * szam;
                Console.ForegroundColor = ConsoleColor.Cyan;
                tippek = Convert.ToInt32(Console.ReadLine());

                if(tippek == eredmeny) 
                {
                    pont++;
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("\n\nElért G.E.R.I pontszám: {0}\n\n", pont);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n----- NYOMJ EGY ENTERT, ÍGY VISSZATÉRSZ A MENÜBE :) -----"); ;
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }

        private static void szorzotabla() 
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("--- Szorzótábla ---");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Írj be egy számot: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            int szam = Convert.ToInt32(Console.ReadLine());

            while (szam != 0) 
            {
                Console.ForegroundColor = ConsoleColor.Cyan;

                if (szam < 11 && szam > 0)
                {
                    Console.WriteLine();
                    for (int i = 0; i < 10; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("{0} * {1} = {2}", i + 1, szam, (i + 1) * szam);
                    }
                }
                else 
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("1 és 10 között adj meg számokat!");
                }
                Console.ForegroundColor = ConsoleColor.Cyan;
                szam = Convert.ToInt32(Console.ReadLine());
            }
        }

        private static void tudnivalok() 
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t-----Szia! az én nevem G.E.R.I-----\n");
            Console.WriteLine(" Hosszabbik nevem: Gyakorlati Eredmények Rendszeres Ismétlése");
            Console.WriteLine(" Elmondom neked a tudnivalókat a szorzótáblával kapcsoltaban, hogy mit is kell csinálnod :)");
            Console.WriteLine("\n\n----------- JÁTÉK -----------");
            Console.WriteLine("\n - A játék elkezdéséhez egy 1-est kell beírnod és akkor egyből bedob a játékba.");
            Console.WriteLine(" - 5 feladatot fogsz kapni a programtól amiket ki kell számolnod.");
            Console.WriteLine(" - Az általad választott szám alapján fog egyenletet felírni amit neked kell kiszámolni.");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" - Sajnos itt nem tudsz visszalépni a menübe! Nem adhatod fel! :)");
            Console.WriteLine(" - ####!FONTOS! 1 és 10 között választhatsz gyakorolhatod a számokat !FONTOS!####");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\n----------- SZORZÓTÁBLA -----------");
            Console.WriteLine("\n - A 2 beírásával elkezdheted megtanulni az adott szorzótáblát.");
            Console.WriteLine(" - Utána add meg azt a számot amit nem tudsz, és annak kiírja a számait 1-től 10-ig és kiszámolja.");
            Console.WriteLine(" - Ne rémülj meg, ha nem lép vissza a menübe! írj be 0-át és akkor visszalép :)");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" - Csak itt tudsz 0-val visszalépni a menübe!");
            Console.WriteLine(" - ####!FONTOS! 1 és 10 között választhatsz gyakorolhatod a számokat !FONTOS!####");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n----- NYOMJ EGY ENTERT, ÍGY VISSZATÉRSZ A MENÜBE :) -----");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void kilepes() 
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("- Biztosan ki akarsz lépni? :)\t(igen/nem)\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            string kilepes = Console.ReadLine();
            kilepes = kilepes.ToLower();

            if (kilepes == "igen" || kilepes == "i")
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n- Hát ez szomorú :(\n- Örültem, hogy megismerhettelek :)\n- Szia!\n\n");
                System.Threading.Thread.Sleep(4000);
                for (int i = 5; i > 0; i--)
                {
                    Console.Clear();
                    Console.Write("Kilépés...({0})", i);
                    System.Threading.Thread.Sleep(600);
                }
                Environment.Exit(0);
            }

            else if (kilepes == "nem" || kilepes == "n")
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n- JEEEJ!!!! :)\n- Akkor folytassuk is :)");
                System.Threading.Thread.Sleep(3000);
            }

            else 
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n- Hmm.... Ezt egy nemnek veszem :)");
                System.Threading.Thread.Sleep(3000);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szorzotabla
{
    class Program
    {
        static int szam = 1;
        static void Main(string[] args)
        {
            menu();
            Console.ReadKey();
        }

        private static void menu() 
        {
            while (true) 
            {
                Console.WriteLine("    Üdvözöllek!");
                Console.WriteLine("------------------");
                Console.WriteLine("| 1. Játék       |");
                Console.WriteLine("| 2. Szorzótábla |");
                Console.WriteLine("| 3. Tudnivalók  |");
                Console.WriteLine("| 4. Kilépés     |");
                Console.WriteLine("-------------------");

                Console.Write("\n#");
                int valasztas = Convert.ToInt32(Console.ReadLine());
                if (valasztas == 1) 
                {
                    jatek();
                }

                else if (valasztas == 2)
                {
                    szorzotabla();
                }

                else if (valasztas == 3)
                {
                    Console.Clear();
                    tudnivalok();
                    Console.ReadKey();
                    Console.Clear();

                }

                else if (valasztas == 4)
                {
                    kilepes();
                }

                else Console.WriteLine("Nincs ilyen szám!");
            }
        }

        private static void jatek() 
        {
            Random rnd = new Random();
            int[] randomszamok = new int[5];
            int jelenlegi_rnd_szam = 0;
            bool ismetlodes = false;

            for(int i = 0; i < randomszamok.Length; i++) 
            {
                do
                {
                    ismetlodes = false;
                    jelenlegi_rnd_szam = rnd.Next(1, 11);

                    for (int j = 0; j < i; j++)
                    {
                        if (randomszamok[j] == jelenlegi_rnd_szam)
                        {
                            ismetlodes = true;
                        }
                    }
                } while (ismetlodes);
                randomszamok[i] = jelenlegi_rnd_szam;
            }


            int tippek;
            int pont = 0;
            int eredmeny;
            Console.Clear();
            Console.WriteLine("--- Játék ---");
            Console.Write("Írj be egy számot: ");
            szam = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0} * {1} = ", randomszamok[i], szam);
                eredmeny = randomszamok[i] * szam;
                tippek = Convert.ToInt32(Console.ReadLine());

                if(tippek == eredmeny) 
                {
                    pont++;
                }
            }
            Console.Write("\n\nElért pontszám: {0}\n\n", pont);
            Console.WriteLine("\n\n----- NYOMJ EGY ENTERT, ÍGY VISSZATÉRSZ A MENÜBE :) -----"); ;
            Console.ReadKey();
            Console.Clear();
        }

        private static void szorzotabla() 
        {
            Console.Clear();
            Console.WriteLine("--- Szorzótábla ---");
            Console.Write("Írj be egy számot: ");

            while(szam != 0) 
            {
                szam = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("{0} * {1} = {2}", i + 1, szam, (i + 1) * szam);
                }

                if(szam == 0) 
                {
                    Console.Clear();
                }
            }
        }

        private static void tudnivalok() 
        {
            Console.WriteLine("\t-----Szia! az én nevem G.E.R.I-----\n");
            Console.WriteLine("- Hosszabbik nevem: Gyakorlati Eredmények Rendszeres Ismétlése");
            Console.WriteLine("- Elmondom neked a tudnivalókat a szorzótáblával kapcsoltaban, hogy mit is kell csinálnod :)");
            Console.WriteLine("\n\n- A játék elkezdéséhez egy 1-est kell beírnod és akkor egyből bedob a játékba.");
            Console.WriteLine("- 5 feladatot fogsz kapni a programtól amiket ki kell számolnod.");
            Console.WriteLine("- Az általad választott szám alapján fog egyenletet felírni amit neked kell kiszámolni.");
            Console.WriteLine("\n\n- A 2 beírásával elkezdheted megtanulni az adott szorzótáblát.");
            Console.WriteLine("- Utána add meg azt a számot amit nem tudsz, és annak kiírja a számait 1-től 10-ig és kiszámolja.");
            Console.WriteLine("- Ne rémülj meg, ha nem lép vissza a menübe! írj be 0-át és akkor visszalép :)");
            Console.WriteLine("\n\n----- NYOMJ EGY ENTERT, ÍGY VISSZATÉRSZ A MENÜBE :) -----");
        }

        private static void kilepes() 
        {
            Environment.Exit(0);
        }
    }
}

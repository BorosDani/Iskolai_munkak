<?php
	header('Content-Type: application/json; charset=utf-8');

	if(!isset($_GET['ev']))
	{
		$tomb = array('hiba' => "hiányos adatok" ,  'uzenet' => "megadandó paraméterek: ev");
	}

	else
	{
		$ev = $_GET['ev'];
		$A = $ev % 19;
		$B = $ev % 4;
		$C = $ev % 7;
		$D = (19 * $A + 24) % 30;
		$E = (2 * $B + 4 * $C + 6*$D + 5) % 7;

		$H1 = 22 + $D + $E;

		if($E == 6 && $D == 29) $H = 50;
		if($E == 6 && $D == 28 && $A > 10) $H = 49;

		$H0 = $H1 - 2;
		$H2 = $H1 + 1;

		$P1 = $H1 + 49 -31 -30;
		$P2 = $H2 + 49 -31 -30;
		
		$h0sz = ($H0 <= 31) ? "Március " . $H0 : "Április " . ($H0 - 31);
		$h1sz = ($H1 <= 31) ? "Március " . $H1 : "Április " . ($H1 - 31);
		$h2sz = ($H2 <= 31) ? "Március " . $H2 : "Április " . ($H2 - 31);

		$p1sz = ($P1 <= 31) ? "Május " . $P1 : "Június " . ($P1 - 31);
		$p2sz = ($P2 <= 31) ? "Május " . $P2 : "Június " . ($P2 - 31);
	}

	$tomb = array(
			' Év               ' => $_GET['ev'],
			' Nagy péntek      ' => $h0sz,
			' Húsvét vasárnap  ' => $h1sz,
			' Húsvét hétfő     ' => $h2sz,
			' Pünkösd vasárnap ' => $p1sz,
			' Pünkösd hétfő    ' => $p2sz,
	);

	$json = json_encode( $tomb , JSON_UNESCAPED_UNICODE ) ;

    print $json ;
?>
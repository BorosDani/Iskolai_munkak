<?php
    //mysqli_connect                        //Kapcsolódás
    //mysqli_query                          //Lekérdezés
    //mysqli_fetch_array                    //Tömb, feldolgozás
    //mysqli_close                          //Lekapcsolódás


    $adb = mysqli_connect("localhost", "root", "", "foldrajz");             

    $tabla = mysqli_query($adb, 
        "SELECT * 
        FROM orszagok
        WHERE orszag LIKE '%Europa%'
        ORDER BY orszag ASC"
    );                

    print "<div id = 'lista'>";
        while($sor = mysqli_fetch_array($tabla))     
        print "<h1><a href = './?oid=$sor[id]'>$sor[orszag]</a></h1>";
    print "</div>";


    $tabla = mysqli_query($adb, 
        "SELECT * 
        FROM orszagok
        WHERE id = '$_GET[oid]'
        ORDER BY orszag ASC"
    );    

    $sor = mysqli_fetch_array($tabla);
    print "<div  id = 'reszlet'>

            </div>";

    mysqli_close($adb);                
?>
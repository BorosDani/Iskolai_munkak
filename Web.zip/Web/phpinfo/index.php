<?php
    print("Hello világ")
    phpinfo();
?>
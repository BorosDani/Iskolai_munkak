<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szorzótábla</title>
</head>
<body>

    <style>
        table
        {
            text-align: center;
            width: 50px;
            border: 2px solid black;
            background-color: lightgreen;
            border-radius: 5px;
            margin: 20px;
        }
        td
        {
            color:white;
            border: 2px solid black;
            background-color: green;
            border-radius: 5px;
        }
    </style>

    <h1>Szorzótábla</h1>
    <table>
    <?php
        if(isset($_GET['a']))
        {
            $a = $_GET['a'];
        }
        else
        {
            $a = 10;
        }

        for($i = 1; $i <= $a; $i++)
        {
            print"
                <tr>
                </tr>";
            for($j = 1; $j <= $a; $j++)
            {
                print"<td>".$i * $j."</td>";
            }
        }
    ?>
    </table>
</body>
</html>
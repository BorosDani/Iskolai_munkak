<?php
    include_once("functions.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal</title>
</head>
<body>
    <form method='POST'>
        <input type="text" name='username' placeholder="Felhsználónév">
        <input type="text" name='password' placeholder="Jelszó">
        <input type="submit" name='login' placeholder="Bejelentkezés">
    </form>

    <form method='POST2'>
        <input type="text" name='email' placeholder="Email cím">
        <input type="text" name='username' placeholder="Felhsználónév">
        <input type="text" name='password' placeholder="Jelszó">
        <input type="submit" name='register' placeholder="Regisztráció">
    </form>

    <?php
        if(isset($_POST["login"]))
        {
            login($_POST);
        }
    ?>
</body>
</html>
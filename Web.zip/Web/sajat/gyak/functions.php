<?php
    session_start();
    include_once("config.php");
    $connection = new Database;
    
    function login($POST)
    {
        $username = $POST["username"];
        $password = md5($POST["password"]);

        if(!empty($username) && !empty($password))
        {
            global $connection;
            $stmt = $connection->pdo->prepare("SELECT * FROM accounts WHERE username = :username and password = :password");
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":password", $password);
            $stmt->execute();
            $result =$stmt->rowCount();
            $account_data = $stmt->fetch(PDO::FETCH_ASSOC);

            if($result == 1)
            {
                $_SESSION["USER:LOGGED"] = true;
                $_SESSION["USER:DATA"] = $account_data;
                print "Sikeres bejelentkezés";
            }else{
                echo "Nincs ilyen felhasználó!";
            }
        }

        else print "Mindenmezőt szükséges kitölteni!";
    }


    function register($POST)
    {
        
    }

?>
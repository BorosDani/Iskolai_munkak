<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <form action='vendegkonyv_ir.php' method='post' target='doboz'>
        <h1 text align='center'>Vendégkönyv</h1>
        <input type='text' name='nevmezo' placeholder='Írd be a neved'><br>

        <textarea name='uzenet' cols='30' rows='10' placeholder='Írj véleményt'></textarea><br>

        <input type='checkbox' name='Nonpc'>Nem vagyok robot<br>
        Kép: <input type='file' name='kep'> <br><br>
        <input type='submit'>
    </form>
    <hr>
    <iframe frameborder='0' name='doboz'></iframe>

    <?php

    ?>
</body>
</html>
<?php
    session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
            if(isset($_GET['p'])) $p = $_GET['p'];
            else $p = "";

            if($p == "") print "Minőségi akciós kütyük?"; else
            if($p == "kapcsolat") print"Milyen kütyüt vegyek?"; else
            if($p == "elerhetoseg") print"Hol vegyek kütyüt?"; else
            if($p == "webshop") print"Kütyük online vására"; else
            if($p == "szavazas") print"Szavazás"; else
            if($p == "vendegkonyv") print"Vendégkönyv";else
            include("404.php");
            print" - kütyübolt.hu"
        ?>
        
    </title>
</head>

<style>
    body
    {
        margin: 0px;
        font-size: 1.5em;
        font-family: "Roboto", sans-serif;
    }

    div#menu
    {
        background-color: #efefef;
        text-align: center;
    }

    div#menu a
    {
        display: inline-block;
        width: 150px;
        color: #1c1c1c;
        text-decoration: none;
        padding: 10px;
    }

    div#menu a:hover
    {
        background-color: #ebebeb;
    }

    div#tartalom
    {
        padding: 12px 48px;
        min-height: 400px;
    }

    div#lablec
    {
        background-color: grey;
    }
</style>

<body>
    <div id = 'menu'>
        <a href="./">Kezdőlap</a>
        <a href="./?p=kapcsolat">Kapcsolat</a>
        <a href="./?p=elerhetoseg">Elérhetőség</a>
        <a href="./?p=webshop">WebShop</a>
        <a href="./?p=szavazas">Szavazás</a>
        <a href="./?p=vendegkonyv">Vendégkönyv</a>
    </div>

    <div id = 'tartalom'>
        <?php
            if(isset($_GET['p'])) $p = $_GET['p'];
            else $p = "";

            if($p == "") print "<h1>!!!!!!!!!!!!!!!!!!!!!!Akciók!!!!!!!!!!!!!!!!!!!!!!</h1>"; else
            if($p == "kapcsolat") print"<h1>Vedd fel velünk a kapcsolatot</h1>"; else
            if($p == "elerhetoseg") print"<h1>Elérhetőségeink</h1>"; else
            if($p == "webshop") print"<h1>Vásárolj kínálatunkból</h1>"; else
            if($p == "szavazas") include("szavazas.php");else
            if($p == "vendegkonyv") include("vendegkonyv.php");else
            include("404.php");
            //INCLUDE-BA rakni mindet!
        ?>
    </div>

    <div id='lablec'>
        <?php
            $fajlnev = date("ymd") . ".txt";
            if(!file_exists($fajlnev))
            {
                $fp = fopen($fajlnev, "w");
                fwrite($fp, "0");
                fclose($fp);
            }
            $fp = fopen($fajlnev, "r");
            $n = fread($fp, filesize($fajlnev));
            fclose($fp);

            if(!isset($_SESSION['izom']))
            {
                $n++;

                $fp = fopen($fajlnev, "w");
                fwrite($fp, $n);
                fclose($fp);

                $_SESSION['izom'] = "évvége";
            }

            print"<span style = 'float:right'>Az oldalt eddig $n látogató látta ma<br></span>";

            $napok = array("","Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap");
            $honapok = array("","Január","Február","Március","Április","Május","Június","Július","Augusztus","Szeptember", "Október", "November", "December");
            print date("Y. ") . $honapok[date("n")]. "".date(" d.")." " . $napok[date("w")];
            print("<br>");
            
            function nevnapos($ev,$ho,$nap)
            {   
                $napok = Array(13);

                    $napok[1] = Array("", "Fruzsina","Ábel","Genovéva és Benjámin","Titusz és Leona",  
                                            "Simon","Boldizsár","Attila és Ramóna","Gyöngyvér","Marcell",  
                                            "Melánia","Ágota","Ernő","Veronika","Bódog","Lóránt és Loránd",  
                                            "Gusztáv","Antal és Antónia","Piroska","Sára, Márió","Fábián és Sebestyén",  
                                            "Ágnes","Vince és Artúr","Zelma és Rajmund","Timót","Pál","Vanda és Paula",  
                                            "Angelika","Károly és Karola","Adél","Martina és Gerda","Marcella");

                if ($ev % 4 != 0)
                    $napok[2] = Array("", "Ignác","Karolina és Aida","Balázs","Ráhel és Csenge","Ágota és Ingrid",  
                                            "Dorottya és Dóra","Tódor és Rómeó","Aranka","Abigél és Alex","Elvira",  
                                            "Bertold és Marietta","Lívia és Lídia","Ella és Linda","Bálint és Valentin",  
                                            "Kolos és Georgina","Julianna és Lilla","Donát és Vilté","Bernadett","Zsuzsanna",  
                                            "Aladár és Álmos","Eleonóra","Gerzson","Alfréd",  
                                            "Mátyás","Géza","Edina","Ákos és Bátor","Elemér","","","");
                else  
                    $napok[2] = Array("", "Ignác","Karolina és Aida","Balázs","Ráhel és Csenge","Ágota és Ingrid",  
                                            "Dorottya és Dóra","Tódor és Rómeó","Aranka","Abigél, Alex","Elvira",  
                                            "Bertold és Marietta","Lívia és Lídia","Ella és Linda","Bálint és Valentin",  
                                            "Kolos és Georgina","Julianna és Lilla","Donát","Bernadett","Zsuzsanna",  
                                            "Aladár és Álmos","Eleonóra","Gerzson","Alfréd",  
                                            "Szökőnap","Mátyás","Géza","Edina","Ákos és Bátor","Elemér","","");

                    $napok[3] = Array("", "Albin","Lujza","Kornélia","Kázmér","Adorján és Adrián","Leonóra és Inez",  
                                            "Tamás","Zoltán","Franciska és Fanni","Ildikó","Szilárd",  
                                            "Gergely","Krisztián és Ajtony","Matild","Kristóf",  
                                            "Henrietta","Gertrúd és Patrik","Sándor és Ede","József és Bánk","Klaudia",  
                                            "Benedek","Beáta és Izolda","Emőke","Gábor és Karina","Irén és Irisz",  
                                            "Emánuel","Hajnalka","Gedeon és Johanna","Auguszta","Zalán","Árpád") ; 

                    $napok[4] = Array("", "Hugó","Áron","Buda, Richárd","Izidor","Vince","Vilmos és Bíborka",  
                                            "Herman","Dénes","Erhard","Zsolt","Leó és Szaniszló","Gyula","Ida",  
                                            "Tibor","Anasztázia és Tas","Csongor","Rudolf","Andrea és Ilma","Emma",  
                                            "Tivadar","Konrád","Csilla és Noémi","Béla","György","Márk","Ervin",  
                                            "Zita","Valéria","Péter","Katalin és Kitti","" );

                    $napok[5] = Array("", "Fülöp és Jakab","Zsigmond","Tímea és Irma","Mónika és Flórián",  
                                            "Györgyi","Ivett és Frida","Gizella","Mihály","Gergely","Ármin és Pálma",  
                                            "Ferenc","Pongrác","Szervác és Imola","Bonifác","Zsófia és Szonja",  
                                            "Mózes és Botond","Paszkál","Erik és Alexandra","Ivó és Milán",  
                                            "Bernát és Felícia","Konstantin","Júlia és Rita","Dezső","Eszter és Eliza",  
                                            "Orbán","Fülöp és Evelin","Hella","Emil és Csanád","Magdolna",  
                                            "Janka és Zsanett","Angéla és Petronella" );

                    $napok[6] = Array("", "Tünde","Kármen, Anita","Klotild","Bulcsú","Fatime","Norbert és Cintia",  
                                            "Róbert","Medárd","Félix","Margit és Gréta","Barnabás","Villő",  
                                            "Antal és Anett","Vazul","Jolán és Vid","Jusztin","Laura és Alida",  
                                            "Arnold és Levente","Gyárfás","Rafael","Alajos és Leila","Paulina",  
                                            "Zoltán","Iván","Vilmos","János és Pál","László","Levente és Irén",  
                                            "Péter és Pál","Pál","" );

                    $napok[7] = Array("", "Tihamér, Annamária","Ottó","Kornél és Soma","Ulrik","Emese és Sarolta",  
                                            "Csaba","Appolónia","Ellák","Lukrécia","Amália","Nóra és Lili",  
                                            "Izabella és Dalma","Jenő","Őrs és Stella","Henrik és Roland","Valter",  
                                            "Endre és Elek","Frigyes","Emília","Illés","Dániel és Daniella",  
                                            "Magdolna","Lenke","Kinga és Kincső","Kristóf és Jakab","Anna és Anikó",  
                                            "Olga és Liliána","Szabolcs","Márta és Flóra","Judit és Xénia","Oszkár" );

                    $napok[8] = Array("", "Boglárka","Lehel","Hermina","Domonkos és Dominika","Krisztina",  
                                            "Berta és Bettina","Ibolya","László","Emőd","Lőrinc",  
                                            "Zsuzsanna és Tiborc","Klára","Ipoly","Marcell","Mária","Ábrahám",  
                                            "Jácint","Ilona","Huba","István","Sámuel és Hajna",  
                                            "Menyhért és Mirjam","Bence","Bertalan","Lajos és Patrícia","Izsó",  
                                            "Gáspár","Ágoston","Beatrix és Erna","Rózsa","Erika és Bella" );

                    $napok[9] = Array("", "Egyed és Egon","Rebeka és Dorina","Hilda","Rozália","Viktor és Lőrinc",  
                                            "Zakariás","Regina","Mária és Adrienn","Ádám","Nikolett és Hunor",  
                                            "Teodóra","Mária","Kornél","Szeréna és Roxána","Enikő és Melitta","Edit",  
                                            "Zsófia","Diána","Vilhelmina","Friderika","Máté és Mirella","Móric",  
                                            "Tekla","Gellért és Mercédesz","Eufrozina és Kende","Jusztina","Adalbert",  
                                            "Vencel","Mihály","Jeromos","" );

                    $napok[10]= Array("", "Malvin","Petra","Helga","Ferenc","Aurél","Brúnó és Renáta","Amália",  
                                            "Koppány","Dénes","Gedeon","Brigitta","Miksa","Kálmán és Ede","Helén",  
                                            "Teréz","Gál","Hedvig","Lukács","Nándor","Vendel","Orsolya","Előd",  
                                            "Gyöngyi","Salamon","Blanka és Bianka","Dömötör",
                                            "Szabina","Simon és Szimonetta","Nárcisz","Alfonz","Farkas" );

                    $napok[11]= Array("", "Marianna","Achilles","Győző","Károly","Imre","Lénárd","Rezső",  
                                            "Zsombor","Tivadar","Réka","Márton","Jónás és Renátó","Szilvia",  
                                            "Aliz","Albert és Lipót","Ödön","Hortenzia és Gergő","Jenő","Erzsébet",  
                                            "Jolán","Olivér","Cecília","Kelemen és Klementina","Emma","Katalin",  
                                            "Virág","Virgil","Stefánia","Taksony","András és Andor","" );

                    $napok[12]= Array("", "Elza","Melinda és Vivien","Ferenc és Olívia","Borbála és Barbara","Vilma",  
                                            "Miklós","Ambrus","Mária","Natália","Judit","Árpád","Gabriella",  
                                            "Luca és Otília","Szilárda","Valér","Etelka és Aletta","Lázár és Olimpia",  
                                            "Auguszta","Viola","Teofil","Tamás","Zéno","Viktória","Ádám és Éva",  
                                            "Eugénia","István","János","Kamilla",  
                                            "Tamás és Tamara","Dávid","Szilveszter" );

                return $napok[$ho][$nap];
            }
            print "Névnap: ";
            print nevnapos(date("Y"),date("n"),date("j"));
            print"<br>";

            $szuletesnap = mktime(0, 0, 0, 11, 20, 2005);
            $evszazadnapok  = (int)((time() - $szuletesnap) / (24*60*60));

            print "$evszazadnapok nappal ezelőtt születtél.<br>Ezen a napon születtél: ".$napok[date("N",$szuletesnap)];
        ?>
    </div>
</body>
</html>
<?php
    session_start();
    print_r($_POST);
    print_r($_FILES );

    $nev = $_POST['nevmezo'];
    $uzenet = $_POST['uzenet'];

    $fajlnev = "vendegkonyv.txt";
    $ido = date("Y.d.m.");

    $kep = $_FILES['kep'] ;

    if(isset($_POST['Nonpc']))
    {
        if(empty($nev))
        {
            print("Üres a névmező!");
        }

        elseif(empty($uzenet))
        {
            print("Nincs üzenet!");
        }
    
        else
        {
            if(!file_exists($fajlnev))
            {
                $fp = fopen($fajlnev, "w");
                fwrite($fp, "$nev| $uzenet| $ido;\n");
                fclose($fp);
            }
            else
            {
                $fp = fopen($fajlnev, "a");
                fwrite($fp, "$nev| $uzenet| $ido;\n");
                fclose($fp);
            }
        }
    }

    else
    {
        print("Sajnálom te egy robot vagy!");
    }
?>
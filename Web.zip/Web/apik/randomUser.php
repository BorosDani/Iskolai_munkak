<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
            $k = isset($_GET['k']) ? $_GET['k'] : "";
        ?>
    </title>
</head>
<body>
    <?php
		$fu   = fopen( "https://randomuser.me/api/" , "r" ) ;
		$json = fread( $fu , 8192 ) ;
		fclose( $fu ) ;

		$adat = json_decode( $json ) ;
        $adat ->results[0] ->email;
	?>

    <div class='userbox'>
        <div class='usercard'>
            <pre>
                <?php
                    print_r($adat->results[0]->picture->medium."\n");    
                    print_r("\nNév:\t\t".$adat->results[0]->name->title." ");
                    print_r($adat->results[0]->name->first." ");
                    print_r($adat->results[0]->name->last);
                    print_r("\n\nNem:\t\t".$adat->results[0]->gender);
                    print_r("\n\nEmail:\t\t".$adat->results[0]->email);
                ?>
            </pre>
        </div>
    </div>
</body>
</html>
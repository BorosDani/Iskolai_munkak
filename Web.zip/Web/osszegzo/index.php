<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Összegző</title>
</head>
<body>

    <style>
        table
        {
            text-align:center;
            width:150px
        }
        td
        {
            text-align:center;
            border: 2px solid black;
        }
    </style>
    
    <h1>Összegző</h1>
        <table>
        <tr>
            <td>N</td>
            <td>Σ N</td>
        </tr>

    <?php
        $osszegzes = 0;
        for($i = 1; $i <101; $i++)
        {
            $osszegzes = $osszegzes + $i;
            print
                "<tr>
                    <td>$i</td>
                    <td>$osszegzes</td>
                </tr>";
        }
    ?>

        <tr>
            <td>N</td>
            <td>Σ N</td>
        </tr>
    </table>

</body>
</html>
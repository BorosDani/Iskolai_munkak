<?php
    session_start();
    if(!$_SESSION['logged']) header('Location: login.php');
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="indexstyle.css">
    <title>Kezdőlap</title>
</head>
<body>
    <div class="menu">
        <form action="logout.php" method="post">
            <input type="button" class="buttons" value="Home page">
            <input type="button" class="buttons" value="About us">
            <input type="submit" class="logout_button" value="Logout">
        </form>
    </div>


    <div class="name">
        <h1>Welcome <?php print $_SESSION['username'];?></h1>
    </div>


    <div class="main">
        <h1>Nem tudom mi lesz itt, de majd lesz</h1>
        <p>Szintén nem tudom, de majd</p>
    </div>
</body>
</html>
<?php
    session_start();
    include_once("connection.php");
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">

    <title>Sign up page</title>
</head>
<body>
<form method="post">
    <div class="title"><h1>Sign up</h1></div>

    <div class="signup_box">
        
        <div class="input_group">
            <img src="https://cdn-icons-png.flaticon.com/512/561/561127.png" alt="email icon" class="input_icon">
            <input type="text" name="email" placeholder="Email">
        </div>

        <div class="input_group">
            <img src="https://cdn-icons-png.flaticon.com/512/1077/1077114.png" alt="user icon" class="input_icon">
            <input type="text" name="username" placeholder="Username">
        </div>

        <div class="input_group">
            <img src="https://cdn-icons-png.flaticon.com/512/3064/3064155.png" alt="lock icon" class="input_icon">
            <input type="password" name="password" placeholder="Password">
        </div>

        <div class="input_group">
            <img src="https://cdn-icons-png.flaticon.com/512/3064/3064155.png" alt="lock icon" class="input_icon">
            <input type="password" name="re_password" placeholder="Password again">
        </div>

    </div>

    <input type="submit" class="confirm_button" name="signup" value="Sign up">
    <div class="question"><p>Do you have an account? then <a href="login.php" class="login_way">Log in</a></p></div>
</form>

</body>
</html>


<?php
    if(isset($_POST['signup']))
    {
            if(empty($_POST['email']) || empty($_POST['username']) || empty($_POST['password']) || empty($_POST['re_password']))
        {
            echo("Kérlek töltsd ki az összes mezőt!");
        }

        elseif($_POST['re_password'] != $_POST['password'])
        {
            echo("A két jelszó nem egyezik!");
        }

        else
        {
            $email = $_POST['email'];
            $username = $_POST['username'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $date = date("Y-m-d H:i:s");
            $role = 'G';

            $query = "INSERT INTO users(email, username, password, role, date) VALUES(?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($con, $query);
            mysqli_stmt_bind_param($stmt, "sssss", $email, $username, $password, $role, $date);
        
            if(mysqli_stmt_execute($stmt))
            {
                echo "Sikeres regisztráció!";
            }

            else
            {
                echo "Hiba történt: ". mysqli_error($con);
            }
        }
    }
?>
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace janosvitez_2
{
    class Program
    {
        static void Main(string[] args)
        {
            feladatok();
        }
        static void feladatok()
        {
            StreamReader olvasocsatorna = new StreamReader(@"D:\dorina\JanosViteeez\JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);
            string[] szavak = olvasocsatorna.ReadLine().Split(' ');
            olvasocsatorna.Close();

            Console.Write("Kérlek adj meg egy betűt: ");
            string betu = Console.ReadLine();
            int osszeg = 0;
            //a betű előfordulásának számolása
            foreach (string szo in szavak)
            {

                foreach (char karakter in szo)
                {
                    if (karakter.ToString().ToLower() == betu.ToLower())
                    {
                        osszeg++;
                    }
                }
                
            }
            Console.WriteLine("A betük előfordulása: " + osszeg);

            

            //c - fordított sorrendben kiírása

            for (int i = szavak.Length - 1; i > 0; i--)
            {
                Console.Write(szavak[i] +" "); 
            }
            Console.WriteLine();

            //d -ritkitás 

            for (int i = 0; i < szavak.Length; i++)
            { 
                
            }

        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace janosvitez_2
{
    class Program
    {
        static void Main(string[] args)
        {
            feladatok();
        }
        static void feladatok()
        {
            /*a.)Kérj be egy betűt, és mondd meg, hányszor szerepel a dokumentumban. 
            Figyelj arra, hogy vannak betűk, melyek egy szóban többször is előfordulhatnak.
            */

            StreamReader olvasocsatorna = new StreamReader(@"Z:\prigi\JanosViteeez\JanosVitez.txt");
            string[] szavak = olvasocsatorna.ReadLine().Split(' ');
            olvasocsatorna.Close();

            Console.Write("Kérlek adj meg egy betűt: ");
            char betu = Convert.ToChar(Console.ReadLine());

            string szo = "";
            int osszeg = 0;

            for (int i = 0; i < szavak.Length; i++)
            {
                char[] kartomb = szo.ToCharArray();
                kartomb[szavak[i].Length] = szavak[i];

                for (int j = 0; j < kartomb.Length; j++)
                {
                    if (kartomb[j] == betu)
                    {
                        osszeg++;
                    }
                }
            }

        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace janosvitez_2
{
    class Program
    {
        static void Main(string[] args)
        {
            feladatok();
        }
        static void feladatok()
        {
            StreamReader olvasocsatorna = new StreamReader(@"C:\Munka\JanosViteeez\JanosVitez.txt", Encoding.GetEncoding("iso-8859-2"), false);
            string[] szavak = olvasocsatorna.ReadLine().Split(' ');
            olvasocsatorna.Close();

            Console.Write("Kérlek adj meg egy betűt: ");
            char betu = Convert.ToChar(Console.ReadLine());
            int osszeg = 0;
            //a betű előfordulásának számolása
            foreach (string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    if (karakter == betu)
                    {
                        osszeg++;
                    }
                }
                
            }
            Console.WriteLine("A betük előfordulása: " + osszeg);
            Console.WriteLine();


            //b - Első szó
            bool elso = false;
            string elso_szo= " ";

            foreach (string szo in szavak)
            {
                foreach (char karakter in szo)
                {
                    
                    while (elso == true)
                    {
                        if (karakter == betu)
                        {
                            elso_szo = szo;
                            elso = true;                                      
                        }
                        
                    }
                }
            }
            Console.WriteLine($"Az első szó amiben szerepel a(z) {betu} betű: {elso_szo}");
            Console.WriteLine();

            //c - fordított sorrendben kiírása
            for (int i = szavak.Length - 1; i > 0; i--)
            {
                Console.Write(szavak[i] +" "); 
            }
            Console.WriteLine();
            Console.WriteLine(  );

            //d -ritkitás 
            foreach (string szo in szavak)
            {
                foreach (char karakterek in szo)
                {
                    Console.Write(karakterek + " ");
                }
                Console.Write(" ");
            }
            Console.WriteLine();


            //e - írás függöleges oszlopba(szó / betű)
            StreamWriter irocsatorna = new StreamWriter(@"C:\Munka\JanosViteeez\JanosVitezFuggolegesSzavak.txt", false, Encoding.GetEncoding("iso-8859-2"));
            irocsatorna.WriteLine("Szavanként:");

            foreach (string szo in szavak)
            {
                irocsatorna.WriteLine(szo);
            }

            irocsatorna.WriteLine("Betűnként:");

            foreach (string szo in szavak)
            {
                foreach (char karakterek in szo)
                {
                    irocsatorna.WriteLine(karakterek);
                }
            }

            irocsatorna.Close();
            Console.ReadKey();
        }
    }
}


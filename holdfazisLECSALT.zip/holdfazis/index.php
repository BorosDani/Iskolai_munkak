<?php
header('Content-Type: application/json; charset=utf-8');

function holdfazisokSzamitasa($referenciaDatum, $fazisokSzama = 3, $irany = 'jovobe') {
    $utolsoIsmertFazis = new DateTime('2021-06-24 20:40');
    $szinodikusHonap = 29.53058867; // nap
    
    $aktualisDatum = new DateTime($referenciaDatum);
    
    $kulonbseg = $aktualisDatum->diff($utolsoIsmertFazis);
    $elteltNapok = $kulonbseg->days + ($kulonbseg->h / 24) + ($kulonbseg->i / 1440);
    
    if ($aktualisDatum < $utolsoIsmertFazis) {
        $elteltNapok = -$elteltNapok;
    }
    
    $elteltHonapok = $elteltNapok / $szinodikusHonap;
    
    if ($irany === 'jovobe') {
        $kezdoFazis = floor($elteltHonapok) + 1;
        $lepes = 1;
    } else { // 'vissza'
        $kezdoFazis = ceil($elteltHonapok) - 1;
        $lepes = -1;
    }
    
    $fazisDatumok = array();
    for ($i = 0; $i < $fazisokSzama; $i++) {
        $napok = ($kezdoFazis + ($i * $lepes)) * $szinodikusHonap;
        $fazisDatum = clone $utolsoIsmertFazis;
        $fazisDatum->add(new DateInterval('P'.round($napok).'D'));
        $fazisDatumok[] = $fazisDatum->format('Y-m-d H:i');
    }
    
    return $fazisDatumok;
}

// Paraméterek kezelése
$megadottDatum = $_GET['datum'] ?? date('Y-m-d');
$fazisokSzama = isset($_GET['db']) ? (int)$_GET['db'] : 3;
$irany = isset($_GET['irany']) && $_GET['irany'] === 'vissza' ? 'vissza' : 'jovobe';

// Holdfázisok számítása
$holdfazisok = holdfazisokSzamitasa($megadottDatum, $fazisokSzama, $irany);

// Válasz előkészítése
$valasz = [
    'referencia_datum' => $megadottDatum,
    'utolso_ismert_fazis' => '2021-06-24 20:40',
    'kereses_iranya' => $irany === 'jovobe' ? 'jövőbe' : 'visszamenőleg',
    'fazisok' => $holdfazisok,
    'szamitas_alapja' => 'Szinodikus hónap (29.53058867 nap)'
];

echo json_encode($valasz, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
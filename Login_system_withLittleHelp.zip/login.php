<?php
    session_start();
    $_SESSION['logged'] = false;
    include_once("connection.php");
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">

    <title>Bejelentkezés</title>
</head>
<body>
    <form method="post">
        <div class="title"><h1>Bejelentkezés</h1></div>
        <div class="login_box">
            <div class="input_group">
                <img src="https://cdn-icons-png.flaticon.com/512/1077/1077114.png" alt="user icon" class="input_icon">
                <input type="text" name="username" placeholder="Felhasználónév / Email">
            </div>
            <div class="input_group">
                <img src="https://cdn-icons-png.flaticon.com/512/3064/3064155.png" alt="lock icon" class="input_icon">
                <input type="password" name="password" placeholder="Jelszó">
            </div>
        </div>

        <input type="submit" class="confirm_button" name="login" value="Bejelentkezés">
        <div class="question"><p>Még nincs fiókod? akkor <a href="signup.php" class="login_way">Regisztrálj</a></p></div>
    </form>
</body>
</html>


<?php
    if(isset($_POST['login']))
    {
        $usernameOrEmail = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "ss", $usernameOrEmail, $usernameOrEmail);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($result))
        {
            if(password_verify($password, $row['password']))
            {
                $_SESSION['logged'] = true;
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['role'];
                header("Location: index.php");
            }

            else
            {
                echo "<script>alert('Hibás jelszó!');</script>";
            }
        }

        else
        {
            echo "<script>alert('Nincs ilyen felhasználó')</script>";
        }
    }
?>
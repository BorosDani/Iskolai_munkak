﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fajlkezeles_2
{
    class Program
    {
        static int a_sav, b_sav, c_sav;
        struct EpitmenyStruktura //Ez egy telek adatainak szerkezete lesz. (Nem tárolunk adatot[Építmény adatszerkezete])
        {
            //Struktúra adatszerkezet megadása.
            public string tulajAdoszam; //A telek tulajdonosának adoszáma
            public string utcaNev;      //A telek utcának a neve
            public string hazSzam;      //A telek házszáma
            public char adosav;         //A telek adósávja (besorolás pl.: A,B,C)
            public int terulet;         //Az építmény alapterülete
        }

        private static int ado(char adosav, int alapterulet)
        {
            int fizetendo_ado;

            if (adosav == 'A')
            {
                fizetendo_ado = a_sav;
            }

            else if (adosav == 'B')
            {
                fizetendo_ado = b_sav;
            }

            else
            {
                fizetendo_ado = c_sav;
            }

            if (fizetendo_ado < 10000)
            {
                fizetendo_ado = 0;
            }
            fizetendo_ado = fizetendo_ado * alapterulet;

            return fizetendo_ado;
        }
        static void Main(string[] args)
        {
            epitmenyado();
            Console.ReadLine();
        }

        private static void epitmenyado()
        {
            //Deklaráció

            //Fálj beolvasása és adatok eltárolása
            StreamReader olvasocsatorna = new StreamReader(@"Z:\prigi\utca.txt");

            string elsosor = olvasocsatorna.ReadLine();
            string sor;

            a_sav = int.Parse(elsosor.Split(' ')[0]);
            b_sav = int.Parse(elsosor.Split(' ')[1]);
            c_sav = int.Parse(elsosor.Split(' ')[2]);

            List<EpitmenyStruktura> adatok = new List<EpitmenyStruktura>(); //Struktúra felhasználásával létrehozott lista.
            string[] darabol;

            while (!olvasocsatorna.EndOfStream) //Amíg nincs vége a fájlnak.
            {
                sor = olvasocsatorna.ReadLine();
                darabol = sor.Split(' ');

                EpitmenyStruktura epitmeny = new EpitmenyStruktura(); //Példányosítás (Adat felvétel)

                epitmeny.tulajAdoszam = darabol[0]; //Itt megkeressük az adószámot (ami a darabolból jön ki) az első elem azaz a 0
                epitmeny.utcaNev = darabol[1];
                epitmeny.hazSzam = darabol[2];
                epitmeny.adosav = char.Parse(darabol[3]);
                epitmeny.terulet = int.Parse(darabol[4]);

                adatok.Add(epitmeny);
            }

            olvasocsatorna.Close();

            Console.WriteLine("1. feladat) Utca.txt beolvasása (megtörtént)");
            //Console.WriteLine("2. feladat. A mintában {0} telek szerepel.", adatok.Count);
            // VAGY
            Console.WriteLine($"\n2. feladat) A mintában {adatok.Count} telek szerepel.");
            Console.Write($"\n3. feladat) Egy tulajdonos adószáma: ");
            string adoszam = Console.ReadLine();
            bool talalat = false;

            for (int i = 0; i < adatok.Count; i++)
            {
                if (adoszam == adatok[i].tulajAdoszam)
                {
                    Console.WriteLine($"{adatok[i].utcaNev} utca {adatok[i].hazSzam}");
                    talalat = true;
                }
            }

            if (!talalat)
            {
                Console.WriteLine("Nem szerepel az adatállományban!");
            }

            Console.WriteLine();

            //5. feladat-adósávok összegzése, db
            Console.WriteLine("5.feladat");
            int A_savDB = 0;
            int A_savÖssz = 0;

            int B_savDB = 0;
            int B_savÖssz = 0;

            int C_savDB = 0;
            int C_savÖssz = 0;

            foreach (EpitmenyStruktura telek in adatok)
            {
                if (telek.adosav == 'A')
                {
                    A_savDB++;
                    A_savÖssz = A_savÖssz + ado(telek.adosav, telek.terulet);
                }
                else if (telek.adosav == 'B')
                {
                    B_savDB++;
                    B_savÖssz = A_savÖssz + ado(telek.adosav, telek.terulet);
                }
                else
                {
                    C_savDB++;
                    C_savÖssz = A_savÖssz + ado(telek.adosav, telek.terulet);
                }
            }

            Console.WriteLine($"A sávba {A_savDB} telek esik, az adó {A_savÖssz} Ft.");
            Console.WriteLine($"B sávba {B_savDB} telek esik, az adó {B_savÖssz} Ft.");
            Console.WriteLine($"C sávba {C_savDB} telek esik, az adó {C_savÖssz} Ft.");

            Console.WriteLine();



            Console.WriteLine("6.feladat. A több sávba sorolt utcák: ");

            HashSet<string> UtcaNevek1 = new HashSet<string>(); //Halmat létre hozása
            HashSet<char> utcaSavok = new HashSet<char>();


            foreach (EpitmenyStruktura telek in adatok)     //select disctint utca név (utcák nevének egyszeri kiírása)
            {
                UtcaNevek1.Add(telek.utcaNev);
            }

            foreach (string utcanev in UtcaNevek1)
            {
                foreach (EpitmenyStruktura telek in adatok)
                {
                    if (utcanev == telek.utcaNev)
                    {
                        utcaSavok.Add(telek.adosav);
                    }
                }

                if (utcaSavok.Count() > 1)
                {
                    Console.WriteLine(utcanev + " ");
                }
                utcaSavok.Clear();
            }



            /*7. feladat: Határozza meg a fizetendő adót tulajdonosonként! A tulajdonos adószámát és a fizetendő összeget írassa ki 
            a mintának megfelelően a fizetendo.txt állományba!A fájlban minden tulajdonos adatai új sorban
            szerepeljenek, a tulajdonos adószámát egy szóközzel elválasztva kövesse az általa fizetendő adó teljes
            összege.*/


            int osszeg = 0;
            HashSet<string> adoszamok = new HashSet<string>();

            foreach (EpitmenyStruktura szemelyadatok in adatok)
            {
                adoszamok.Add(szemelyadatok.tulajAdoszam);
            }

            StreamWriter irocsatorna = new StreamWriter("fizetendo.txt");

            foreach (string szemelyadoszam in adoszamok)
            {
                foreach (EpitmenyStruktura telek in adatok)
                {
                    if (telek.tulajAdoszam == szemelyadoszam)
                    {
                        osszeg = osszeg + ado(telek.adosav, telek.terulet);
                    }
                }
                irocsatorna.WriteLine($"{szemelyadoszam} {osszeg}");
                osszeg = 0;
            }

            irocsatorna.Close();

            Console.WriteLine("\n7. feladat: A fizetendo.txt elkészült.");
        }
    }
}
<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>
        <?php
            $p = isset($_GET['p']) ? $_GET['p'] : "";
            if($p == "") echo"Kezdőlap"; else
            if($p == "kutyak") echo"Kutyusok"; 
            else echo"404 - Az oldal nem található";
        ?>
    </title>
</head>
<body>
    <h1 align='center'>Különböző API-t használt feladatok</h1>

    <div class='menu'>  
        <a href="./?p=">Kezdőlap</a>
        <a href="?p=kutyak">Kutyák api</a>
    </div>

    <?php
        if($p == "") include_once("index.php"); else
        if($p == "kutyak") include("kutyak.php"); 
        else include("404.php");
    ?>
</body>
</html>
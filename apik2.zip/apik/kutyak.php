<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        <?php
            $k = isset($_GET['k']) ? $_GET['k'] : "";
        ?>
    </title>
</head>
<body>
    <div class='dogbox'>
        <h2 align='center'>Válassz egy kutya fajtát</h2>
        <div class='dogmenu'>
            <a href="?p=kutyak&k=germanshepherd">Német juhász</a>
            <a href="?p=kutyak&k=beagle">Beagle</a>
            <a href="?p=kutyak&k=akita">Akita</a>
            <a href="?p=kutyak&k=vizsla">Vizsla</a>
            <a href="?p=kutyak&k=chihuahua">Chihuahua</a>
        </div>
        <?php
                $faj = "https://dog.ceo/api/breed/$k/images/random";

                $fk = @fopen($faj, "r");
                if($fk)
                {
                    $json = fread( $fk , 8192 ) ;
                    fclose( $fk ) ;

                    $adat = json_decode( $json ) ;

                    print "<div class='dogimage'> <img src='$adat->message' width=300px height=300px title='$adat->message'></div>";
                }
                else
                {
                    print "A dog.ceo API-ja jelenleg nem működik." ;
                }
	    ?>
    </div>

</body>
</html>
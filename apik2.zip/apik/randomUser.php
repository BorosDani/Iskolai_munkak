<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php
            $k = isset($_GET['k']) ? $_GET['k'] : "";
        ?>
    </title>
</head>
<body>
    <?php
		$fu   = fopen( "https://randomuser.me/api/" , "r" ) ;
		$json = fread( $fu , 8192 ) ;
		fclose( $fu ) ;

		$adat = json_decode( $json ) ;
        $nev = $adat->results[0]->name->title . $adat->results[0]->name->first . $adat->results[0]->name->last;
        $nem = $adat->results[0]->gender;
        $lakhely = $adat->results[0]->location->country . $adat->results[0]->location->city;
        $email = $adat ->results[0] ->email;
        $telefon = $adat->results[0]->phone;
        $felhasznalonev = $adat->results[0]->login->username;
        $jelszo = $adat->results[0]->login->password;
        $kep = $adat->results[0]->picture->large;
	?>

    <div class='userbox'>
        <div class='usercard'>
            <table>
                <tr>
                    <td>
                        Név:<br><br>
                        Nem:<br><br>
                        Születési dátum:<br><br>
                        lakhely:<br><br>
                        Email:<br><br>
                        Telefonszám:<br><br>
                        Felhasználónév:<br><br><br><br>
                    <td>
                        
                    <td>
                        <input type="text"><br><br>
                        <input type="radio" name="nem">Férfi
                        <input type="radio" name="nem">Nő<br><br>
                        <input type="date"><br><br>
                        <input type="text"><br><br>
                        <input type="text"><br><br>
                        <input type="text"><br><br>
                        <input type="text" name='jelszo'><br><br><br>
                        <input type="submit" value="Random user generálása" name='randuserbutton'>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
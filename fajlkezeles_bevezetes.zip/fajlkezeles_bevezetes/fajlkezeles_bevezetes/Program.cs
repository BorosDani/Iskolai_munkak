﻿using System;
using System.IO; //!!!!!Ez kell a fájlkezeléshez!!!!!
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fajlkezeles_bevezetes
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             
                1. lépés:   Fájl létrehozása és megnyitása.
                2. lépés:   Író vagy olvasó csatorna létrehozása.
                3. lépés:   Fájl olvasása/írása.
                4. lépés:   Fájl bezárása. (Garbage collector)
             

                2 féle típusú fájl formátum: - Szöveges (nincs formázás, csak karakterek) [txt, csv, VSCode]
                                             - Bineáris (képek, hangok, videók)

             */

            /*
           fel01();
           Console.ReadLine();


           fel02();
           Console.ReadLine();
           

            fel03();
           Console.ReadLine();
           

            fel04();
            Console.ReadLine();
            

            fel05();
            Console.ReadLine();
            */

            fel06();
            Console.ReadLine();
        }

        private static void fel01() 
        {
            // Fájlba írás streamwriter segítségével.
            Console.WriteLine("Fájlba írás...");
            //StreamWriter irocsatorna = new StreamWriter("hello.txt");                      //[ELÉRÉSIÚTVONAL NÉLKÜL]
            StreamWriter irocsatorna = new StreamWriter(@"Z:\programozas\hello.txt", false, Encoding.GetEncoding("iso-8859-2"));        // [ELÉRÉSIÚTVONALLAL]   Encoding.GetEncoding("iso-8859-2") HA ÉKEZETES  false

            irocsatorna.WriteLine("Hallo, Dani vagyok.");
            irocsatorna.WriteLine("Ez a fájl második sora.");
            irocsatorna.WriteLine("Tesztelem az ékezetes betűket őűüöúáé");

            irocsatorna.Close();

            Console.WriteLine("Fájlba írás kész...");
        }


        private static void fel02() 
        {
            //Fájl tartalmának beolvasása.
            Console.WriteLine("Fájl beolvasás...\n");
            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas\hello.txt", Encoding.GetEncoding("iso-8859-2"), false);   // Encoding.GetEncoding("iso-8859-2") HA NINCS MEGADVA, AKKOR NINCSENEK ÉKEZETES BETŰK

            Console.WriteLine(olvasocsatorna.ReadLine());
            Console.WriteLine(olvasocsatorna.ReadLine());
            Console.WriteLine(olvasocsatorna.ReadLine());

            olvasocsatorna.Close();
            Console.WriteLine("\nFájl beolvasva...");
        }


        private static void fel03() 
        {
            Console.WriteLine("Fájlba írás....(Bekérünk db mennyiségű számot és random generálunk 50-500 ig számokat melyeket mindig új sorba kiírunk egy veletlenek.txt fájlba.)");
            Console.Write("Feldobások száma: ");

            int db = Convert.ToInt32(Console.ReadLine());
            StreamWriter irocsatorna = new StreamWriter(@"Z:\programozas\veletlenek.txt", false);
            Random veletlen = new Random();

            for(int i = 0; i < db; i++) 
            {
                irocsatorna.WriteLine(veletlen.Next(50, 501));
            }

            irocsatorna.Close();
            Console.WriteLine("Fájlba írás kész...");
        }


        private static void fel04() 
        {
            Console.WriteLine("Fájlt beolvasunk úgy, hogy nem tudjuk pontosan hány sora van (ameddig van sor addig menjen).\n");

            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas\veletlenek.txt", false);
            string sor = olvasocsatorna.ReadLine();

            while (sor != null) 
            {
                Console.WriteLine(sor);
                sor = olvasocsatorna.ReadLine();
            }

            olvasocsatorna.Close();
            Console.WriteLine("\nFájl beolvasva...");
        }


        private static void fel05() 
        {
            Console.WriteLine("A fájlban (veletlenek) lévő számoknak ki kell számolni az átlagát.\n");

            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas\veletlenek.txt", false);
            string sor = olvasocsatorna.ReadLine();
            int darab = 0;
            double osszeg = 0;

            while (sor != null) 
            {
                darab++;
                osszeg = Convert.ToInt32(sor) + osszeg;
                sor = olvasocsatorna.ReadLine();
            }

            olvasocsatorna.Close();

            Console.WriteLine("Darab = {0}\nÖsszeg ={1}\nÁtlag = {2}", darab, osszeg, osszeg/darab);
            Console.WriteLine("\nFájl beolvasva...");
        }


        private static void fel06() 
        {
            Console.WriteLine("Pénzfeldobás ---> Megkérdezzük a felhasználót, hogy hány feldobás legyen és azt ki kell írni fájlba.\n");
            Console.Write("Feldobások száma: ");

            int db = Convert.ToInt32(Console.ReadLine());
            int jelenlegi_rand_szam = 0;
            Random rnd = new Random();
            //StreamWriter irocsatorna = new StreamWriter(@"Z:\programozas\penzfeldobas.txt", false);
            StreamWriter irocsatorna = new StreamWriter(@"D:\Saját mappák\Dani\Programozás\C#_programok\iskolai_12\penzfeldobas.txt", false);

            for (int i = 0; i < db; i++) 
            {
                jelenlegi_rand_szam = rnd.Next(0, 2);

                if (jelenlegi_rand_szam == 0)
                {
                    irocsatorna.WriteLine("F");
                }
                else 
                {
                    irocsatorna.WriteLine("I");
                }
            }

            irocsatorna.Close();
            Console.WriteLine("\nFájlba írás kész...");
        }
    }
}

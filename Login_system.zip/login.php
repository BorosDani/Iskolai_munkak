<?php
    session_start();
    $_SESSION['logged'] = false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="post">
        <div class="login_box">
            <input type="texbox" name="usern" placeholder="Username"><br>
            <input type="password" name="pass" placeholder="Password">
        </div>
        <input type="submit" class="confirm_button" name="login" value="Login">
        <a href="signup.php">Signup</a>
    </form>
</body>
</html>

<?php
    if(isset($_POST['login']))
    {
        $_SESSION['usern'] = $_POST['usern'];
        $_SESSION['pass'] = $_POST['pass'];

        if($_SESSION['pass'] == $password && $_SESSION['usern'] == $username)
        {
            $_SESSION['logged'] = true;
            header('Location: main.php');
        }
    
        else 
        {
            print "<script> alert('Sikertelen bejelentkezés!'); </script>";
        }
    }
?>
<?php
    session_start();
    if(!$_SESSION['logged']) header('Location: login.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kezdőlap</title>
</head>
<body>
    <div class="menu">
        <form action="logout.php" method="post">
            <input type="submit" class="logout_button" value="Logout">
        </form>
    </div>

    <h1>Üdvözöllek <?php print $_SESSION['usern'];?></h1>
</body>
</html>